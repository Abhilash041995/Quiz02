<?php
include "include/connect.php";
session_start();
if($_SESSION['id']=="" || $_SESSION['email']=="")
{
header("location:index.php");
}
$id=$_SESSION['id'];
$sql="select * from signup where id='$id'";
$res=mysql_query($sql,$conn);
$row=mysql_fetch_array($res);

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Oline Quiz</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<?php include"welcome.php";?>
<div class="container">
  <h2>Welcome <?php echo $row['name'];?> To Quiz</h2>
  <p>Score Your High Score & Win The Prize</p>            
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Name</th>
        <th>E-Mail</th>
        <th>Password</th>
        <th>Image</th>
      </tr>
    </thead>
    
    <tr>
      <th><?php echo $row['name'];?></th>
      <th><?php echo $row['email'];?></th>
      <th><?php echo $row['password'];?></th>
      <th><img src="upload/<?php echo $row['image'];?>" width="80"; height="60";
      ></th>
    </tr>
    
  </table>
</div>

</body>
</html>
