<?php
include "include/connect.php";
session_start();
if($_SESSION['id']=="" || $_SESSION['email']=="")
{
header("location:index.php");
}
$sql="select * from category";
$res=mysql_query($sql,$conn);


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Online Quiz</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Online Quiz</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="home.php">Home</a></li>
       <li><a href="pro.php">Profile</a></li>
        
      </li>
    
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="logout.php"><span class="glyphicon glyphicon-user"></span> LogOut</a></li>
      
    </ul>
  </div>
</nav>
  <div class="container">
 
  <center><a href="#select" data-toggle="tab" class="btn btn-info" role="button">Start Quiz</a></center>
  <div class="col-sm-4"></div>
  <div class="col-sm-4"><br>
     <div id="select" class="tab-pane fade">
      <form method="POST" action="ques.php">
      <select class="form-control" id="" name="cat">

      <option value="select category" disabled="disabled">select category</option>
     <?php
      while($row=mysql_fetch_array($res))
      {
      ?>
    
        <option value="<?php echo $row['id'];?>"><?php echo $row['cat_name']; ?></option>
        <?php
        }
        ?>
       
      </select><br>
      <center><input type="submit" name="submit"  class="btn btn-info" value="Start"></center>
  </div>
    </div>
  </div>



</body>
</html>
