<?php
include "include/connect.php";
if(isset($_POST['submit']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['pwd'];
$file=$_FILES['file']['name'];
    move_uploaded_file($_FILES['file']['tmp_name'],"upload/".$_FILES['file']['name']);
    $sql="insert into signup(id,name,email,password,image)values('','$name','$email','$password','$file')";
    mysql_query($sql,$conn);
}
if(isset($_POST['sub']))
{
$email=$_POST['email'];
$password=$_POST['pwd'];
$sql="select * from signup where email='$email' and password='$password'";
$res=mysql_query($sql,$conn);
$row=mysql_fetch_array($res);
if($row['email']=="")
{
?>
<script type="text/javascript">
  alert("Enter The valide Email & Password!!");
</script>
<?php
}
else
{
session_start();
$_SESSION['id']=$row['id'];
$_SESSION['email']=$row['email'];
header("location:home.php");
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Online Quiz</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body> 
 
<div class="container">
 <div class="row">
     <div class="col-sm-12">
       <h4>Online Quiz System</h4>
       <div class="panel-group">
         <div class="panel panel-warning">
           <div class="panel-body">Quiz In PHP</div>
        </div>
       </div>
      </div>
  </div>
</div>
<div class="container">
<div class="row">
   <div class="col-sm-6">
     <div class="panel panel-success">
      <div class="panel-heading">
        <h4>Login form</h4></div>
          <div class="panel-body">
            <form method="post" enctype="multipart/form-data">
              <div class="form-group">
               <label for="email">Email:</label>
                 <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
              </div>
              <div class="form-group">
              <label for="pwd">Password:</label>
              <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
              </div>
             <div class="checkbox">
             <label><input type="checkbox" name="remember"> Remember me</label>
             </div>
             <input type="submit"  class="btn btn-default" name="sub" value="Login">
            
             </form>
          </div>
      </div>
    </div>

    <div class="col-sm-6">
     <div class="panel panel-success">
      <div class="panel-heading">
        <h4>SignUp form</h4></div>
          <div class="panel-odby">
            <form method="post" enctype="multipart/form-data">
            <div class="form-group">
               <label for="name">Name:</label>
                 <input type="text" class="form-control" required="Enter name" id="name" placeholder="Enter name" name="name">
              </div>
              <div class="form-group">
               <label for="email">Email:</label>
                 <input type="email" class="form-control" required="Enter email" id="email" placeholder="Enter email" name="email">
              </div>
              <div class="form-group">
              <label for="pwd">Password:</label>
              <input type="password" class="form-control" required="Enter password" id="pwd" placeholder="Enter password" name="pwd">
              </div>
              <div class="form-group">
               <label for="file">Upload Image:</label>
                 <input type="file" class="form-control" required="upload file" id="file" name="file">
              </div>
             <div class="checkbox">
             <label><input type="checkbox" name="remember"> Remember me</label>
             </div>
             <input type="submit" class="btn btn-default" name="submit" value="SignUp">
             
             </form>
          </div>
      </div>
    </div>


</div>
</div>


</body>
</html>