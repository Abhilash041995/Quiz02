<?php
include "include/connect.php";
session_start();

$data=$_POST;

$ans=implode("",$data);

$right=0;
$wrong=0;
$no_ans=0;
$sql="select id,ans from questions where cat_id='".$_SESSION['cat']."'";
$res=mysql_query($sql,$conn);
while($row=mysql_fetch_array($res))
{
if($row['ans']==$_POST[$row['id']])
{
   $right++;
}
elseif($_POST[$row['id']]=='Not_attemt')
{
	$no_ans++;
}
else
{
	$wrong++;
}

}
$total_que=0;
$total_att=0;
$total_que=($right+$wrong+$no_ans);
$total_att=$total_que-($no_ans);



?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<?php include "welcome.php";?>
<?php

?>
<div class="container">
<div class="col-sm-2">
	<a href="home.php" class="btn btn-info">Back</a>
</div>
<div class="col-sm-8">
  <h2><center>Quiz Result</center></h2>
              
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Total Number Of Questions</th>
        <th><?php echo $total_que;?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Total Attempt questions</td>
        <td><?php echo $total_att;?></td>
      </tr>
      <tr>
        <td>Right Answers</td>
        <td><?php echo $right;?></td>
      </tr>
      <tr>
        <td>Wrong Answers</td>
        <td><?php echo $wrong;?></td>
      </tr>
       <tr>
        <td>Not Attempt</td>
        <td><?php echo $no_ans;?></td>
      </tr>
      <tr>
        <td>Total Score</td>
        <td><?php echo $right;?> / 10.</td>
      </tr>
       
    </tbody>
  </table>
  </div>
  <div class="col-sm-4"></div>
</div>
<div class="col-sm-4" style="float: right;">
<input  type="button" class="btn btn-info" value="Print this page" onclick="window.print()">
</div>
</body>
</html>
