<?php

include "include/connect.php";
session_start();
if($_SESSION['id']=="" || $_SESSION['email']=="")
{
header("location:index.php");
}
$qes=$_POST['cat'];
$_SESSION['cat']=$_POST['cat'];
$sql="select * from questions where cat_id='$qes'";
$res=mysql_query($sql,$conn);





?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript">
  function timeout()
  {
  	var minute=Math.floor(timeleft/60);
  	var second=timeleft%60;
  	if(timeleft<=0)
  	{
  		clearTimeout(tm);
  		document.getElementById("form1").submit();
  	}
  	else
  	{
  		document.getElementById("time").innerHTML=minute+":"+second;
  	}
  	timeleft--;
  	var tm=setTimeout(function(){timeout()},1000);

  }
  	
  </script>
</head>
<body onload="timeout()">
<?php include "welcome.php";?>

<div class="container">
<div class="col-sm-2"></div>
<div class="col-sm-8">
  <h2>Online Quiz 
<script type="text/javascript">
	var timeleft=1*60;
</script>

  <div id="time" style="float: right;">Time</div></h2>

  <p>PHP</p> 
    <form method="POST" id="form1" action="ans.php">  
  <?php
  $i=1;
 while($row=mysql_fetch_array($res))
  {
  ?>  
       
  <table class="table table-bordered">
    <thead>
      <tr>
        <th><?php echo $i.")";?><?php echo $row['questions'];?></th>
      </tr>
    </thead>
    <tbody>
    <?php if(isset($row['ans1']))
    {
    	?>
      <tr>
        <td>1.<input type="radio" value="0" name="<?php echo $row['id'];?>"><?php echo $row['ans1'];?></td>
        </tr>
        <?php
        }
        ?>
        <?php if(isset($row['ans2']))
        {
        	?>
        <tr>
        <td>2.<input type="radio" value="1" name="<?php echo $row['id'];?>"><?php echo $row['ans2'];?></td>
        </tr>
        <?php
        }
        ?>
        <?php if(isset($row['ans3']))
        {
        	?>
        <tr>
        <td>3.<input type="radio" value="2" name="<?php echo $row['id'];?>"><?php echo $row['ans3'];?></td>
        
      </tr>
      <?php
      }
      ?>
      <tr>
        <td><input type="radio" checked="checked" style="display:none;" value="Not_attemt" name="<?php echo $row['id'];?>"></td>
        </tr>
     
   
    </tbody>
  </table>
 
  <?php
  $i++; }
  ?>
  <center><input type="submit"  class="btn btn-info" value="Submit"></center>
</form>
  </div>
  <div class="col-sm-2"></div>
</div>

</body>
</html>
